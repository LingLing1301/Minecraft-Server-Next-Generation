### Minecraft Server Next Generation

#### Auchor: LingLing1301
#### Page: https://space.bilibili.com/472148300
#### Support: https://www.patreon.com/LingLing1301

**Game List**
1. Bedwars
2. Skywars
3. Murder Mystery

**Directions**
- The "#" comment is to explain the meaning of the uplink command, not the downlink command
- The Servers/op directory contains functions available to administrators
- The /reload command reloads datapacks

**Development Matters**

Start:
Shop Module/Place&Break/Assets Module/Died-reSpawn-Bed Module
Victory: Return the Lobby

- More:
AutoStartModule
TeamChestSettings
GamerulesSettings
TimeSettings
WeatherSettings
Team&CollisionRuleSettings
AdvancementSettings
WorldBorderSettings
NoCrafting
NotBreakMyselfBed
AssetsPointNoBlock
AttackSpeedSetting
AssetsPointNoMoreItem
NotSaturationSettings
InLobbyNoDie
AdminManagerSettings
NoCheatSettings
DifficultySettings
Level&Experience-System
Added LobbyAndGameMaps

- Preformance:
Higher TPS
Higher FPS
Lower Entity and Entity Block
Number of Lower Commands
Preformance Commands




















**起床战争模块**
1. 计时开始(检测人数,开始倒数,人满快进倒数)
2. 开始函数(随机分队,执行开始一系列函数)
3. 重置函数
4. 生成资源
5. 玩家不能破坏自己的床
6. 商店
7. 资源生成点防堵
8. 设置杀死后能重生
9. 设置破坏床后不能重生
10. 资源点定时升级
11. 设置胜利
























